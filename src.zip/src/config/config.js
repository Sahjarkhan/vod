module.exports = {
    UrlImage: 'https://mobuloustech.com/yodapi/public/',
    Url: 'https://mobuloustech.com/yodapi/'
}

